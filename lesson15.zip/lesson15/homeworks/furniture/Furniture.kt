package org.example.lessons.lesson15.homeworks.furniture

open class Furniture(
    val name: String,
    val material: String
) {
}