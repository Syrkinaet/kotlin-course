package org.example.lessons.lesson15.homeworks.furniture

abstract class Bedroom(
    name: String,
    material: String
) : Furniture(name, material) {
}