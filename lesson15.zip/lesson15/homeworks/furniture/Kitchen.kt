package org.example.lessons.lesson15.homeworks.furniture

open class Kitchen(
    name: String,
    material: String,
    val color: String
) : Furniture(name, material) {
}