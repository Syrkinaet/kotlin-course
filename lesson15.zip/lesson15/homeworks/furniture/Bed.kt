package org.example.lessons.lesson15.homeworks.furniture

class Bed(
    name: String,
    material: String,
    val cloth: String
) : Bedroom(name, material) {
}