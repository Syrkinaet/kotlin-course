package org.example.lessons.lesson15.homeworks.educationalEstablishments

class School(
    name: String,
    yearOfFoundation: Int,
    val shape: String
): EducationEstablishment(name, yearOfFoundation) {
}