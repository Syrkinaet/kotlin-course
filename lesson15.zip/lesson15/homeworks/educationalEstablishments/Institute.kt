package org.example.lessons.lesson15.homeworks.educationalEstablishments

open class Institute(
    name: String,
    yearOfFoundation: Int,
    val rating: Double
): EducationEstablishment(name, yearOfFoundation)  {
}