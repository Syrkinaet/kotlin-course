package org.example.lessons.lesson15.homeworks.educationalEstablishments

open class EducationEstablishment(
    val name: String,
    val yearOfFoundation: Int
) {
}